export const stateCode = {
  success: 200,
  // 验证失败
  authFail: 201,
  // 查询失败
  findFail: 202,
  // 新增或者修改失败
  cpdFail: 203,
};
