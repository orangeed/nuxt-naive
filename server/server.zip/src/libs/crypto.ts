export const cryptoConstants = {
  privateKey: '1208917130@qq.com',
};
