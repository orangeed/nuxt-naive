export interface GetHomeTatal {
    totalDose: number
    sugger: number
    dose: number
}

export interface Result {
    code: number
    message?: string
    data?: any
}